from CvorTablice import CvorTablice


error = False
nema_main = True

korijen = None
doseg = CvorTablice()

definirane_funkcije = list()
deklarirane_funkcije = list()